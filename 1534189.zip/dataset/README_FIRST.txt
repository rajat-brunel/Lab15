++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Worksheet 15 TSP Data
Brunel University, Computer Science Department
Module CS2004 Algorithms and thier Applications, (2016-2017)
Travelling Salesman Problem
Module Leader: Dr Stephen Swift, stephen.swift@brunel.ac.uk
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

ZIP File Contents:

README_FIRST.txt: this file!

TSP_<N>.txt: distance file for N cities, N rows by N columns (real numbers), separated by a space, 31 files in total

TSP_OPT<N>.txt: optimal tour for file TSP_<N>.txt, N rows of one integer, 8 files in total

TSP.java: three methods in a TSP java class, for reading in an array (city distance file), printing an array 
          and reading in a tour file (integer list file)